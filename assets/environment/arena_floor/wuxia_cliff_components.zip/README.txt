武侠门派·后山崖壁 参考图拆分包
================================

建议用途：
- 把每张 PNG 作为单独视觉参考交给 Codex / Blender 脚本。
- A/B/C 用于远景山体组合。
- D/E/F/G/H 用于中景、可拼接岩壁模块。
- I/J/K 用于前景松树+岩石点缀。
- L/M 用于竹林岩台。
- N/O 用于特殊远景焦点。
- *_three_view_reference.png 用于辅助建模比例、轮廓和侧面体积判断。

推荐给 Codex 的实现方式：
1. 每个组件独立建模并单独导出 GLB。
2. 统一坐标：Z up，原点放在模型底部中心。
3. 统一材质风格：低多边形岩体 + 灰白岩石 + 深绿色植被。
4. 树木、竹子尽量实例化，避免每棵树都做独立高模。
5. 远景 A/B/C 可低面数；中景 D-H 需要更完整轮廓和碰撞体。
6. 最终在 Godot 中用 PackedScene 拼装，不要烘焙成一个超大模型。

文件说明：
- 00_overview_gate_mountains.png
- A_main_peak.png
- B_continuous_ridge.png
- C_sharp_peak_cluster.png
- A_three_view_reference.png
- D_broad_cliff_wall.png
- E_broken_cliff_wall.png
- F_terraced_rock.png
- G_vertical_rock_pillar.png
- H_right_overhang_cliff.png
- D_three_view_reference.png
- I_welcoming_pine_rock.png
- J_lone_pine_cliff.png
- K_pine_peak.png
- L_bamboo_platform_large.png
- M_bamboo_platform_small.png
- N_waterfall_cliff.png
- O_misty_peak_cluster.png
